[验证码](https://blog.csdn.net/aaaadong/article/details/90645113)

[表单验证](https://blog.csdn.net/wyansai/article/details/103339026)

[gin session](https://github.com/gin-contrib/sessions)
