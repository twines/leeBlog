/*
@Author :   寒云
@Email  :   1355081829@qq.com
@Time : 2019/12/26 10:12
*/
package routers

import (
	"encoding/gob"
	"leeblog.com/app/http/controller/admin"
	"leeblog.com/app/http/middleware"
	"leeblog.com/app/model"
)

//import "leeblog.com/app/http/controller/admin"

// adminRouter 后台管理路由
func adminRouter() {
	gob.Register(model.Admin{})
	router := router()
	//router.HTMLRender = loadTemplates("templates", "admin")
	router.Static("/layuiadmin", "./static/layuiadmin")
	adminRouter := router.Group("admin")
	adminRouter.Use(middleware.Session("admin"))
	{
		adminRouter.GET("/login", admin.LoginIndex)
		adminRouter.GET("/captcha", admin.Captcha)
		adminRouter.GET("/captcha/:value", admin.CaptchaVerify)
		adminRouter.POST("/login", admin.LoginDoLogin)
	}
	adminAuth := adminRouter.Group("")
	adminAuth.Use(middleware.AdminAuth())
	{
		adminAuth.GET("/", admin.IndexIndex)
		adminAuth.GET("/home/index", admin.HomeIndex)
		//人力管理
		adminAuth.GET("/user/index", admin.UserIndex)
		//商户管理
		adminAuth.GET("/shop/index", admin.ShopIndex)
		adminAuth.GET("/shop/list", admin.ShopList)
		adminRouter.GET("/driver/index", admin.DriverIndex)
		adminRouter.GET("/driver/list", admin.DriverList)
		adminRouter.GET("/task/index", admin.TaskIndex)
	}
}
