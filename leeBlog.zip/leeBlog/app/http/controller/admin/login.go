package admin

import (
	"fmt"
	"github.com/gin-gonic/gin"
	"leeblog.com/pkg/utils"
	"net/http"
)

func LoginIndex(c *gin.Context) {
	fmt.Println(utils.AuthCheck(c, "admin"))
	utils.View(c, "/admin/login/index.html")
}
func LoginDoLogin(c *gin.Context) {
	name := c.PostForm("username")
	password := c.PostForm("password")
	verifyCode := c.PostForm("verifyCode")
	if !utils.CaptchaVerify(c, verifyCode) {
		c.JSON(http.StatusOK, gin.H{"code": 1, "msg": "验证码错误"})
		return
	}
	admin := adminService.GetAdminByName(name)
	if admin.ID <= 0 {
		c.JSON(http.StatusOK, gin.H{"code": 1, "msg": "用户不存在"})
	} else {
		pwd := utils.EncodeMD5(password)
		if pwd != admin.Password {
			c.JSON(http.StatusOK, gin.H{"code": 1, "msg": "密码错误"})
			return
		}
		utils.Auth(c, "admin", admin)
		c.JSON(http.StatusOK, gin.H{"code": 0, "msg": "成功1111"})
	}
}
