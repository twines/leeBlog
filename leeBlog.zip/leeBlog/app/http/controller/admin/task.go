package admin

import (
	"github.com/gin-gonic/gin"
	"leeblog.com/pkg/utils"
)

func TaskIndex(c *gin.Context) {
	taskService.GetTaskList()
	utils.View(c, "/admin/task/index.html")
}
