package admin

import (
	"github.com/gin-gonic/gin"
	"leeblog.com/pkg/utils"
)

func IndexIndex(c *gin.Context) {
	utils.View(c, "/admin/index/index.html")
}
