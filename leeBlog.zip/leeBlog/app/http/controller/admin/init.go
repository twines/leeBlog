package admin

import "leeblog.com/app/service/admin"

var (
	adminService  = admin.NewAdminsService()
	shopService   = admin.NewShopService()
	driverService = admin.NewDriverService()
	taskService   = admin.NewTaskService()
)
