package admin

import (
	"github.com/gin-gonic/gin"
	"leeblog.com/pkg/utils"
)

func UserIndex(c *gin.Context) {
	utils.View(c, "/admin/user/index.html")
}
