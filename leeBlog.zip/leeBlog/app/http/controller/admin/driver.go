package admin

import (
	"github.com/gin-gonic/gin"
	"leeblog.com/pkg/utils"
	"net/http"
)

func DriverIndex(c *gin.Context) {
	utils.View(c, "/admin/driver/index.html")
}
func DriverList(c *gin.Context) {
	var where = map[string]interface{}{}
	if driverName := c.Query("driverName"); driverName != "" {
		where["driver_name"] = driverName
	}
	driverSlice, count := driverService.GetDriverList(where)
	c.JSON(http.StatusOK, gin.H{"code": 0, "msg": "", "count": count, "data": driverSlice})
}
