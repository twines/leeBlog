package admin

import (
	"github.com/gin-gonic/gin"
	"leeblog.com/pkg/utils"
	"net/http"
	"strconv"
)

func ShopIndex(c *gin.Context) {
	utils.View(c, "/admin/shop/index.html")
}
func ShopList(c *gin.Context) {
	page := 1
	if p, err := strconv.Atoi(c.DefaultQuery("page", "1")); err == nil {
		page = p
	}

	var where = map[string]interface{}{}
	if shopName := c.Query("shopName"); shopName != "" {
		where["shop_name"] = shopName
	}
	shopSlice, count := shopService.GetShopList(where, page, 15)
	c.JSON(http.StatusOK, gin.H{"code": 0, "msg": "success", "count": count, "data": shopSlice})
}
