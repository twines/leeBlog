package web

import (
	"fmt"
	"github.com/gin-gonic/gin"
	"leeblog.com/app/model"
	"leeblog.com/app/service/web"
	"leeblog.com/pkg/utils"
	"net/http"
	"strconv"
)

func BlogDetail(c *gin.Context) {
	if id, err := strconv.Atoi(c.Param("id")); err != nil {
	} else {
		blog := web.NewBlog().GetBlogById(id)
		blog.View += 1
		web.NewBlog().UpdateBlog(blog)
		utils.View(c, "/web/blog/detail.html", gin.H{"blog": blog})
	}
}
func BlogAdd(c *gin.Context) {
	childCategory := web.NewCategory().GetChildCategory()
	utils.View(c, "/web/blog/add.html", gin.H{"childCategory": childCategory})
}
func BlogDoAdd(c *gin.Context) {
	categoryId, _ := strconv.Atoi(c.PostForm("category"))
	blog := model.Blog{
		Title:       c.PostForm("title"),
		Content:     c.PostForm("content"),
		CategoryId:  categoryId,
		Description: c.PostForm("description"),
	}
	web.NewBlog().AddBlog(blog)
	c.Redirect(http.StatusFound, "/")
}
func BlogEdit(c *gin.Context) {
	if id, err := strconv.Atoi(c.Param("id")); err != nil {
		utils.View404(c)
	} else {
		blog := web.NewBlog().GetBlogById(id)
		user, _ := c.Get("user")
		if user.(model.User).ID != uint(blog.UserId) {
			utils.View404(c)
		}
		childCategory := web.NewCategory().GetChildCategory()
		utils.View(c, "/web/blog/edit.html", gin.H{"blog": blog, "childCategory": childCategory})
	}
}
func BlogUpdate(c *gin.Context) {
	if id, err := strconv.Atoi(c.Param("id")); err != nil {
		utils.View404(c)
	} else {
		blog := web.NewBlog().GetBlogById(id)
		if blog.ID <= 0 {
			utils.View404(c)
		} else {

			blog.Title = c.PostForm("title")
			blog.Content = c.PostForm("content")
			blog.ID = uint(id)
			if categoryId, err := strconv.Atoi(c.PostForm("category")); err == nil {
				blog.CategoryId = categoryId
			}
			blog.Description = c.PostForm("description")
			web.NewBlog().UpdateBlog(blog)
		}
		c.Redirect(http.StatusFound, fmt.Sprintf("/blog/detail/%d", blog.ID))
	}
}
