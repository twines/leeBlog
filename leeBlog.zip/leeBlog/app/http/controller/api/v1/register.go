package v1

import "github.com/gin-gonic/gin"

// @Tags v1
// @Summary 注册
// @Description ```javascript $(document).ready(function () { alert('RUNOOB'); }); ```
// @Produce  json
// @Param id path int true "ID"
// @Param Auth header string true "token"
// @Param name query string false "ID"
// @Success 200 {object} doc.Msg "成功"
// @Failure 404 {object} doc.Msg "失败"
// @Router /api/v1/register/post [post]
func RegisterPost(c *gin.Context) {
}
