package doc

type Msg struct {
	Code int
	Msg  string
}
