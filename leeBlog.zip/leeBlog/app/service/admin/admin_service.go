package admin

import "leeblog.com/app/model"

type AdminsService struct {
}

func NewAdminsService() *AdminsService {
	return &AdminsService{}
}


func (a *AdminsService) GetAdminByName(name string) (admin model.Admin) {
	model.DB().Where("name=?", name).First(&admin)
	return
}
