package admin

import (
	"leeblog.com/app/model"
)

type ShopService struct {
}

func NewShopService() *ShopService {
	return &ShopService{}
}

func (shop *ShopService) GetShopList(where map[string]interface{}, page int, limit int) (shopSlice []model.Shop, count int) {
	model.DB().Where(where).Offset((page - 1) * limit).Limit(limit).Find(&shopSlice).Count(&count)
	return
}
