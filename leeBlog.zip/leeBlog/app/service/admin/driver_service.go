package admin

import "leeblog.com/app/model"

type DriverService struct {
}

func NewDriverService() *DriverService {
	return &DriverService{}
}
func (driver *DriverService) GetDriverList(where map[string]interface{}) (driverSlice []model.Driver, count int) {
	model.DB().Where(where).Find(&driverSlice).Count(&count)
	return
}
