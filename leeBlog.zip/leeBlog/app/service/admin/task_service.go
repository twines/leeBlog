package admin

import "leeblog.com/app/model"

type TaskService struct {
}

func NewTaskService() *TaskService {
	return &TaskService{}
}

func (ts *TaskService) GetTaskList() {
	model.DB()
}
