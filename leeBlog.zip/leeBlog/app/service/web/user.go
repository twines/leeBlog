package web

import "leeblog.com/app/model"

type User struct {
}

func NewUser() *User {
	return &User{}
}
func (u User) AddUser(user User) {
	model.DB().Create(&user)
}
func (u User) GetUser(user model.User) (userModel model.User) {
	model.DB().Where(user).First(&userModel)
	return
}
