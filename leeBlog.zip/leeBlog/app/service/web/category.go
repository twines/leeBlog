package web

import "leeblog.com/app/model"

type Category struct {
}

func NewCategory() *Category {
	return &Category{}
}

func (category *Category) GetChildCategory() (categorySlice []model.Category) {
	model.DB().Where("parent_id>?", 0).Find(&categorySlice)
	return
}
func (category *Category) GetParentCategory() (categorySlice []model.Category) {
	model.DB().Where("parent_id=?", 0).Find(&categorySlice)
	return
}
