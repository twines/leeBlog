package web

import (
	"leeblog.com/app/model"
)

type Blog struct {
}

func NewBlog() *Blog {
	return &Blog{}
}
func (blog *Blog) GetBlogList(categoryId int, page int) (blogSlice []model.Blog, count int) {
	if categoryId > 0 {
		model.DB().Where("category_id=?", categoryId).Find(&Blog{}).Count(&count)
		model.DB().Order("id desc").Where("category_id=?", categoryId).Offset((page - 1) * 15).Limit(15).Find(&blogSlice)
	} else {
		model.DB().Find(&Blog{}).Count(&count)
		model.DB().Order("id desc").Offset((page - 1) * 15).Limit(15).Find(&blogSlice).Count(&count)
	}
	return
}

func (blog *Blog) GetGoodBlog() (blogSlice []model.Blog) {
	model.DB().Order("view desc,id desc").Limit(6).Find(&blogSlice)
	return
}
func (blog *Blog) GetBlogById(id int) (b model.Blog) {
	model.DB().First(&b, id)
	return
}
func (blog *Blog) AddBlog(b model.Blog) (id uint) {
	model.DB().Create(&b)
	return b.ID
}

func (blog *Blog) UpdateBlog(b model.Blog) (id int64) {
	d := model.DB().Save(&b)
	return d.RowsAffected
}
