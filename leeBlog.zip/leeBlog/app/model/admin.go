package model

type Admin struct {
	Model
	Name string
	Password string
}
