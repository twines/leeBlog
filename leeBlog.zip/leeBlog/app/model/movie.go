package model

type Movie struct {
	Model
	MovieName  string
	MovieCover string
	MovieTip   string
}
