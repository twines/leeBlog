package model

type Driver struct {
	Model
	DriverName     string	`json:"driverName"`
	DriverMobile   string `json:"driverMobile"`
	DriverAvatar   string `json:"driverAvatar"`
	DriverIdNumber string `json:"driverIdNumber"`
}
