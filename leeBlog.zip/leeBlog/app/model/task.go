package model

type Task struct {
	Model
	TaskTitle       string `json:"taskTitle"`
	TaskDescription string `json:"taskDescription"`
}
