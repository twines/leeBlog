package model

import "leeblog.com/pkg/utils"

type Shop struct {
	Model
	ShopName    string         `json:"shopName"`
	ShopAddress string         `json:"shopAddress"`
	JoinAt      utils.JSONTime `json:"joinAt"`
	Mobile      string         `json:"mobile"`
	Phone       string         `json:"phone"`
	Email       string         `json:"email"`
}
