package model

type Category struct {
	Model
	CategoryName string
	ParentId     int
}
